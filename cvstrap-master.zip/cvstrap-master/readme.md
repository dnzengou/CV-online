<a href="http://demo.evenfly.com/view?theme=CVstrap"><img src="http://i0.wp.com/shapebootstrap.net/wp-content/uploads/2015/03/cvstrap-shapebootstrap-cover.jpg?resize=850%2C660" alt="CVstrap - Free Minimal CV HTML5/Bootstrap Template by EvenFly"></a>

CVstrap - Free Minimal CV HTML5/Bootstrap Template by EvenFly
------------------------------------

Thank you for choosing CVstrap

CVstrap is another Free minimal CV HTML template by EvenFly built with Bootstrap 3.3.0. and released under Creative Commons 3.0 license.

Live demo: http://demo.evenfly.com/view?theme=CVstrap

As long the codes already well commented, we don't think there's any additional help guide necessary.

Even so, feel free to contact us through support@evenfly.com if you have any question/suggestion regarding the template.

If you like this template, you may like to see our other themes and templates  available at https://www.evenfly.com/themes/

Or follow us on
https://www.facebook.com/evenflyteam
https://twitter.com/EvenFlyTeam


License
------------------------------------
Creative Commons Attribution 3.0 Unported
https://creativecommons.org/licenses/by/3.0/


Special Thanks!
------------------------------------
- Design: https://www.facebook.com/towkirahmedbappy
- Icons: http://fontawesome.io
- Fonts: http://google.com/fonts
- NiceScroll: https://github.com/inuyaksa/jquery.nicescroll